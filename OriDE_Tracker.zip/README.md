# OriDETracker
PopTracker Package for OriDE Archipelago Implementation, this package is currently missing logic. 

## Installation

Download the latest release from the releases section, and then move it into `/poptracker/packs/` and you're all set!

## Tracker Info

This tracker supports Archipelago Autotracking and is designed for Archipelago.

## More Info

Download Poptracker [here](https://github.com/black-sliver/PopTracker)

Join the ['Unofficial' PopTracker Discord Server](https://discord.com/invite/gwThqMCPgK)!